# Library-Management-System-in-Java
Library Management System :

The project titled Library Management System is Library management
software for monitoring and controlling the transactions in a library .The
project “Library Management System” is developed in java, which mainly
focuses on basic operations in a library like adding new member, new books,
and updating new information, searching books and members and facility to
borrow and return books.

The software Library Management System has four main modules.
Insertion to Database Module – User friendly input screen.
Extracting from Database module – Attractive Output Screen.
Report Generation module – borrowed book list & Available book list.
Search Facility system – search for books and members.

Features Of The Library Management System
1. Menu driven: Project consists of various menus through which we can put
required options.
2. Validations: There are proper validations for the information filled in the
relevant field. Therefore, the chance of wrong entry saved is minimize.
3. Reports: The reports for the required information can be generate easily by
just clicking the button to get details. Reports can be printed.
4. Error messages: The system provides user-friendly environment for every
new user. Even a person who has low knowledge about the system can use
the project. As long as error messages concerned, there is a particular
error on every unauthorized entry and wrong input. There is proper
provision for error message whenever an error occurs.
5. User friendly: The proposed system is properly user friendly so that end
user has very less knowledge of using computer easily work on the
software.
6. Security: The proposed system almost secured by a login id and password
so that nobody can use the system without right and permission.
